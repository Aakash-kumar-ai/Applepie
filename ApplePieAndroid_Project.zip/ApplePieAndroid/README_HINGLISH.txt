ApplePie Android starter project

Is project mein:
- App ka naam ApplePie hai.
- Open karte hi full-screen prank surprise screen dikhegi.
- Ek halka repeating beep effect hai (original sound asset ki zaroorat nahi).
- Volume buttons normal kaam karte hain.
- Android Back button se app band ki ja sakti hai.
- App background mein jaate hi sound ruk jaata hai.

APK banane ke liye:
1. Android Studio install/open karo.
2. File > Open se is extracted ApplePieAndroid folder ko select karo.
3. Gradle sync complete hone do.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK app/build/outputs/apk/debug/app-debug.apk mein milegi.

Note: Yeh Android Studio source project hai, ready-made APK nahi.
