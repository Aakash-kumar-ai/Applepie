package com.example.applepie

import android.app.Activity
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private var tone: ToneGenerator? = null
    private val handler = Handler(Looper.getMainLooper())
    private var playing = false

    private val beep = object : Runnable {
        override fun run() {
            if (!playing) return
            tone?.startTone(ToneGenerator.TONE_PROP_BEEP, 180)
            handler.postDelayed(this, 650)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32, 32, 32, 32)
            setBackgroundColor(0xFF160D24.toInt())
        }

        val emoji = TextView(this).apply {
            text = "😈"
            textSize = 92f
            gravity = Gravity.CENTER
        }
        val title = TextView(this).apply {
            text = "SURPRISE!\n\nAPPLEPIE"
            textSize = 30f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "Just a prank 😄\nPress your phone's Back button to leave."
            textSize = 17f
            setTextColor(0xFFD8CBE8.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 0)
        }
        layout.addView(emoji)
        layout.addView(title)
        layout.addView(subtitle)
        setContentView(layout)
    }

    override fun onStart() {
        super.onStart()
        playing = true
        tone = ToneGenerator(AudioManager.STREAM_MUSIC, 45)
        handler.post(beep)
    }

    override fun onStop() {
        playing = false
        handler.removeCallbacks(beep)
        tone?.release()
        tone = null
        super.onStop()
    }

    override fun onDestroy() {
        playing = false
        handler.removeCallbacks(beep)
        tone?.release()
        tone = null
        super.onDestroy()
    }
}
